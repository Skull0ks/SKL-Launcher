#!/usr/bin/env bash
# Установщик SKL Launcher для Linux (любой дистрибутив)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$HOME/.local/share/skl-launcher"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/256x256/apps"

echo "=== Установка SKL Launcher ==="

# 1) Если в архиве есть готовый бинарник и он запускается, Python не нужен
USE_BIN=0
if [ -f "$HERE/skl-launcher" ]; then
  chmod +x "$HERE/skl-launcher"
  if "$HERE/skl-launcher" --check >/dev/null 2>&1; then USE_BIN=1; fi
fi

# 2) Иначе нужен Python 3 с tkinter
has_tk() { command -v python3 >/dev/null 2>&1 && python3 -c "import tkinter" >/dev/null 2>&1; }

if [ "$USE_BIN" = "0" ] && [ "${SKL_SKIP_DEPS:-0}" != "1" ] && ! has_tk; then
  echo "Нужны Python 3 и tkinter. Ставлю их (может потребоваться пароль)..."
  if [ "$(id -u)" -eq 0 ]; then SUDO=""
  elif command -v sudo >/dev/null 2>&1; then SUDO="sudo"
  elif command -v doas >/dev/null 2>&1; then SUDO="doas"
  else SUDO=""; fi
  if   command -v apt-get     >/dev/null 2>&1; then $SUDO apt-get update && $SUDO apt-get install -y python3 python3-tk
  elif command -v dnf         >/dev/null 2>&1; then $SUDO dnf install -y python3 python3-tkinter
  elif command -v yum         >/dev/null 2>&1; then $SUDO yum install -y python3 python3-tkinter
  elif command -v pacman      >/dev/null 2>&1; then $SUDO pacman -S --needed --noconfirm python tk
  elif command -v zypper      >/dev/null 2>&1; then $SUDO zypper install -y python3 python3-tk
  elif command -v apk         >/dev/null 2>&1; then $SUDO apk add python3 py3-tkinter
  elif command -v xbps-install >/dev/null 2>&1; then $SUDO xbps-install -Sy python3 python3-tkinter
  elif command -v eopkg       >/dev/null 2>&1; then $SUDO eopkg install -y python3 tk
  elif command -v nix-env     >/dev/null 2>&1; then
    echo "NixOS: запусти  nix-shell -p python3 python3Packages.tkinter  и повтори ./install.sh внутри него."; exit 1
  else
    echo "Не удалось определить пакетный менеджер. Установи Python 3 с модулем tkinter вручную и запусти install.sh снова."
    exit 1
  fi
  if ! has_tk; then
    echo "tkinter не установился. Установи его вручную и запусти install.sh снова."
    exit 1
  fi
fi

mkdir -p "$APP_DIR" "$BIN_DIR" "$APPS_DIR" "$ICON_DIR"
cp "$HERE/skl-launcher.png" "$ICON_DIR/skl-launcher.png"
cp "$HERE/uninstall.sh" "$APP_DIR/uninstall.sh"
chmod +x "$APP_DIR/uninstall.sh"

if [ "$USE_BIN" = "1" ]; then
  cp "$HERE/skl-launcher" "$APP_DIR/skl-launcher"
  chmod +x "$APP_DIR/skl-launcher"
  RUN_CMD="exec \"$APP_DIR/skl-launcher\" \"\$@\""
else
  cp "$HERE/skl_launcher.py" "$APP_DIR/skl_launcher.py"
  RUN_CMD="exec python3 \"$APP_DIR/skl_launcher.py\" \"\$@\""
fi
printf '#!/usr/bin/env bash\n%s\n' "$RUN_CMD" > "$BIN_DIR/skl-launcher"
chmod +x "$BIN_DIR/skl-launcher"

cat > "$APPS_DIR/skl-launcher.desktop" << DESKTOP
[Desktop Entry]
Type=Application
Name=SKL Launcher
Comment=Лаунчер Minecraft
Exec=$BIN_DIR/skl-launcher
Icon=$ICON_DIR/skl-launcher.png
Terminal=false
Categories=Game;
StartupWMClass=SKLLauncher
DESKTOP

# Ярлык на рабочем столе
DESK="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
if [ -d "$DESK" ]; then
  cp "$APPS_DIR/skl-launcher.desktop" "$DESK/skl-launcher.desktop"
  chmod +x "$DESK/skl-launcher.desktop"
  gio set "$DESK/skl-launcher.desktop" metadata::trusted true >/dev/null 2>&1 || true
fi
update-desktop-database "$APPS_DIR" >/dev/null 2>&1 || true

echo
echo "Готово! SKL Launcher установлен."
echo "Запусти его из меню приложений, ярлыком на рабочем столе или командой: skl-launcher"
case ":$PATH:" in *":$BIN_DIR:"*) ;; *) echo "(Команда skl-launcher заработает после перезахода в систему.)";; esac
