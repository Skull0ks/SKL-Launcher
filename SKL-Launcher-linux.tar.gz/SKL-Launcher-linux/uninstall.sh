#!/usr/bin/env bash
# Удаление SKL Launcher
APP_DIR="$HOME/.local/share/skl-launcher"
rm -rf "$APP_DIR"
rm -f "$HOME/.local/bin/skl-launcher"
rm -f "$HOME/.local/share/applications/skl-launcher.desktop"
rm -f "$HOME/.local/share/icons/hicolor/256x256/apps/skl-launcher.png"
DESK="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
rm -f "$DESK/skl-launcher.desktop"
echo "SKL Launcher removed."
if [ -d "$HOME/.skl-launcher" ]; then
  read -r -p "Also delete game data (versions, worlds, mods) in ~/.skl-launcher? [y/N] " ans
  case "$ans" in [yY]*) rm -rf "$HOME/.skl-launcher"; echo "Data deleted.";; *) echo "Game data kept.";; esac
fi
