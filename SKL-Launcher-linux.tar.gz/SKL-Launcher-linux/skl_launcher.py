# -*- coding: utf-8 -*-
"""SKL Launcher — минималистичный лаунчер Minecraft (Windows).
Версии: Vanilla / Forge / Fabric / OptiFine. Ник вводится вручную (офлайн-режим).
Только стандартная библиотека Python 3.9+ (tkinter)."""
import os, sys, json, random, ctypes, hashlib, threading, subprocess, zipfile, uuid, re, time, shutil, queue
import urllib.request
import platform, tarfile
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, messagebox

APP = "SKL Launcher"
APP_VER = "1.0"
IS_WIN = sys.platform.startswith("win")
OS_NAME = "windows" if IS_WIN else "linux"
ARCH = platform.machine().lower()
IS_ARM = ARCH in ("aarch64", "arm64")
IS_X86_32 = ARCH in ("i386", "i686", "x86")
FONT = "Segoe UI" if IS_WIN else "DejaVu Sans"
FONT_SYM = "Segoe UI Symbol" if IS_WIN else "DejaVu Sans"
FOLDER_ICON = "📁  " if IS_WIN else ""
if IS_WIN:
    ROOT = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), ".skl-launcher")
else:
    ROOT = os.path.join(os.path.expanduser("~"), ".skl-launcher")
VERSIONS = os.path.join(ROOT, "versions")
LIBS = os.path.join(ROOT, "libraries")
ASSETS = os.path.join(ROOT, "assets")
RUNTIME = os.path.join(ROOT, "runtime")
INSTANCES = os.path.join(ROOT, "instances")
CACHE = os.path.join(ROOT, "cache")
CONFIG = os.path.join(ROOT, "config.json")
_T = [
    ('skipped', 'Пропущено: %s (%s)', 'Skipped: %s (%s)'),
    ('dl_ver', 'Скачиваю описание версии %s...', 'Downloading version info %s...'),
    ('dl_mc', 'Скачиваю Minecraft %s...', 'Downloading Minecraft %s...'),
    ('dl_java', 'Скачиваю Java %d (один раз)...', 'Downloading Java %d (one time)...'),
    ('dl_java_pct', 'Скачиваю Java %d: %d%% (%.1f из %.1f МБ, %.1f МБ/с)', 'Downloading Java %d: %d%% (%.1f of %.1f MB, %.1f MB/s)'),
    ('dl_java_mb', 'Скачиваю Java %d: %.1f МБ (%.1f МБ/с)', 'Downloading Java %d: %.1f MB (%.1f MB/s)'),
    ('java_mirror', 'Не удалось скачать Java (%s). Пробую другой источник...', 'Could not download Java (%s). Trying another source...'),
    ('java_bad', 'Скачанный файл Java повреждён. Запусти игру ещё раз.', 'The downloaded Java file is damaged. Launch the game again.'),
    ('unpack_java', 'Распаковываю Java...', 'Unpacking Java...'),
    ('java_fail', 'Не удалось установить Java', 'Failed to install Java'),
    ('forge_dl', 'Скачиваю установщик Forge...', 'Downloading Forge installer...'),
    ('forge_inst', 'Устанавливаю Forge (это может занять пару минут)...', 'Installing Forge (this may take a couple of minutes)...'),
    ('forge_fail', 'Установщик Forge завершился с кодом %s. Смотри лог.', 'Forge installer exited with code %s. See the log.'),
    ('fabric_dl', 'Скачиваю Fabric...', 'Downloading Fabric...'),
    ('of_dl', 'Скачиваю OptiFine...', 'Downloading OptiFine...'),
    ('of_patch', 'Патчу Minecraft под OptiFine...', 'Patching Minecraft for OptiFine...'),
    ('of_fail', 'Не удалось пропатчить OptiFine (код %s)', 'Failed to patch OptiFine (code %s)'),
    ('share_fail', 'Не удалось подключить общую папку %s', 'Could not link shared folder %s'),
    ('share_err', 'Общая папка %s: %s', 'Shared folder %s: %s'),
    ('dl_libs', 'Скачиваю библиотеки...', 'Downloading libraries...'),
    ('dl_assets', 'Скачиваю ресурсы...', 'Downloading assets...'),
    ('nick', 'НИК', 'NICKNAME'),
    ('mcver', 'ВЕРСИЯ MINECRAFT', 'MINECRAFT VERSION'),
    ('snaps', 'Показывать снапшоты и старые версии', 'Show snapshots and old versions'),
    ('lver', 'ВЕРСИЯ ЗАГРУЗЧИКА', 'LOADER VERSION'),
    ('play', 'ИГРАТЬ', 'PLAY'),
    ('download', 'СКАЧАТЬ', 'DOWNLOAD'),
    ('downloading', 'СКАЧИВАЮ...', 'DOWNLOADING...'),
    ('installed_ok', 'Версия скачана. Можно играть!', 'Version downloaded. Ready to play!'),
    ('openfolder', 'Открыть папку игры', 'Open game folder'),
    ('loading', 'Загрузка списка версий...', 'Loading version list...'),
    ('showlog', 'показать лог ▾', 'show log ▾'),
    ('hidelog', 'скрыть лог ▴', 'hide log ▴'),
    ('settings', 'Настройки', 'Settings'),
    ('ram', 'ОПЕРАТИВНАЯ ПАМЯТЬ', 'MEMORY'),
    ('ramfmt', '%d МБ  (%.1f ГБ)', '%d MB  (%.1f GB)'),
    ('raminfo', 'Всего ОЗУ в ПК: %.1f ГБ. Для модов обычно хватает 4–6 ГБ.', 'Total RAM: %.1f GB. 4–6 GB is usually enough for mods.'),
    ('hide', 'Прятать лаунчер, пока запущена игра', 'Hide the launcher while the game is running'),
    ('anim', 'Анимированный фон', 'Animated background'),
    ('shared', 'Общие моды, шейдеры и ресурспаки для всех версий', 'Shared mods, shaders and packs for all versions'),
    ('done', 'Готово', 'Done'),
    ('language', 'ЯЗЫК', 'LANGUAGE'),
    ('data_err', 'Ошибка загрузки данных: %s', 'Failed to load data: %s'),
    ('newver', 'Новые версии: ', 'New versions: '),
    ('ready', 'Готово', 'Ready'),
    ('nick_err', 'Ник: 3–16 символов, только латиница, цифры и _', 'Nickname: 3–16 characters, Latin letters, digits and _ only'),
    ('vers_wait', 'Список версий ещё не загрузился.', 'The version list has not loaded yet.'),
    ('no_lver', 'Нет версии загрузчика для этой версии игры.', 'No loader version is available for this game version.'),
    ('starting', 'ЗАПУСК...', 'STARTING...'),
    ('game_start', 'Игра запускается...', 'Launching the game...'),
    ('log_launch', 'Запуск: ', 'Launching: '),
    ('game_run', 'Игра запущена. Приятной игры!', 'The game is running. Have fun!'),
    ('game_closed', 'Игра закрыта', 'Game closed'),
    ('closed_code', ' (код %s, смотри лог)', ' (code %s, see the log)'),
    ('err', 'Ошибка: %s', 'Error: %s'),
    ('err_log', 'ОШИБКА: %s', 'ERROR: %s'),
]
STR = {"ru": {k: r for k, r, e in _T}, "en": {k: e for k, r, e in _T}}
LANG = "en"
LANG_WIDGETS = []

def set_lang(l):
    global LANG
    LANG = l if l in ("ru", "en") else "en"

def tr(key, *a):
    v = STR[LANG].get(key) or STR["en"][key]
    return v % a if a else v

def reg(w, key):
    """Запоминает виджет, чтобы обновить его текст при смене языка."""
    LANG_WIDGETS.append((w, key))
    return w

def initial_lang(cfg):
    """(язык, нужно ли спросить). Windows: язык из установщика или вопрос при первом запуске. Linux: английский."""
    if cfg.get("lang") in ("ru", "en"):
        return cfg["lang"], False
    try:
        with open(os.path.join(ROOT, "lang.txt"), encoding="utf-8") as f:
            v = f.read().strip()
        if v in ("ru", "en"):
            return v, False
    except Exception:
        pass
    return "en", IS_WIN

SHARED = ("mods", "resourcepacks", "shaderpacks")      # общие для всех версий
for d in (VERSIONS, LIBS, ASSETS, RUNTIME, INSTANCES, CACHE) + tuple(os.path.join(ROOT, n) for n in SHARED):
    os.makedirs(d, exist_ok=True)

MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
FORGE_META = "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml"
FORGE_MAVEN = "https://maven.minecraftforge.net/net/minecraftforge/forge"
FORGE_PROMOS = "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"
FABRIC_META = "https://meta.fabricmc.net/v2/versions"
OPTIFINE_LIST = "https://bmclapi2.bangbang93.com/optifine/versionList"
OPTIFINE_DL = "https://bmclapi2.bangbang93.com/optifine/{mc}/{type}/{patch}"
UA = {"User-Agent": "SKL-Launcher/1.0"}
NO_WINDOW = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW

# ───────────────────────── сеть / файлы ─────────────────────────
def http_get(url, timeout=30, tries=3):
    last = None
    for _ in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(1)
    raise last

def get_json(url):
    return json.loads(http_get(url).decode("utf-8"))

def sha1_of(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def download(url, path, sha1=None, size=None, tries=3):
    if os.path.exists(path):
        if size is not None:
            if os.path.getsize(path) == size:
                return
        elif sha1:
            if sha1_of(path) == sha1:
                return
        else:
            return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    last = None
    for _ in range(tries):
        try:
            tmp = path + ".part"
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r, open(tmp, "wb") as f:
                shutil.copyfileobj(r, f, 1 << 18)
            os.replace(tmp, path)
            return
        except Exception as e:
            last = e
            time.sleep(1)
    raise last

def maven_path(name):
    ext = "jar"
    if "@" in name:
        name, ext = name.split("@")
    p = name.split(":")
    cl = "-" + p[3] if len(p) > 3 else ""
    return "%s/%s/%s/%s-%s%s.%s" % (p[0].replace(".", "/"), p[1], p[2], p[1], p[2], cl, ext)

def lib_key(name):
    p = name.split("@")[0].split(":")
    return ":".join([p[0], p[1]] + p[3:4])

def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v.split("-")[0].split("_")[0])[:3])

# ───────────────────────── правила и версии ─────────────────────────
def rule_ok(rules):
    if not rules:
        return True
    ok = False
    for r in rules:
        m = True
        o = r.get("os")
        if o:
            if o.get("name") not in (None, OS_NAME):
                m = False
            if "arch" in o and not ((o["arch"] == "x86" and IS_X86_32) or (o["arch"] == "arm64" and IS_ARM)):
                m = False
        f = r.get("features")
        if f and any(f.values()):
            m = False
        if m:
            ok = r.get("action") == "allow"
    return ok

def load_version(vid):
    p = os.path.join(VERSIONS, vid, vid + ".json")
    with open(p, encoding="utf-8") as f:
        d = json.load(f)
    if "inheritsFrom" in d:
        parent = load_version(d["inheritsFrom"])
        m = dict(parent)
        for k, v in d.items():
            if k == "libraries":
                m["libraries"] = v + parent.get("libraries", [])
            elif k == "arguments":
                pa = parent.get("arguments", {})
                m["arguments"] = {"game": pa.get("game", []) + v.get("game", []),
                                  "jvm": pa.get("jvm", []) + v.get("jvm", [])}
            elif k != "inheritsFrom":
                m[k] = v
        m["_root"] = parent["_root"]
        return m
    d["_root"] = d["id"]
    return d

def collect_args(lst):
    out = []
    for a in lst:
        if isinstance(a, str):
            out.append(a)
        elif rule_ok(a.get("rules")):
            v = a["value"]
            out += [v] if isinstance(v, str) else v
    return out

def offline_uuid(nick):
    return str(uuid.UUID(bytes=hashlib.md5(("OfflinePlayer:" + nick).encode()).digest(), version=3))

# ───────────────────────── установка ─────────────────────────
class Reporter:
    def __init__(self, app):
        self.app = app
    def status(self, t): self.app.ui(self.app.set_status, t)
    def log(self, t): self.app.ui(self.app.add_log, t)
    def progress(self, d, t): self.app.ui(self.app.set_progress, d, t)

def run_jobs(jobs, rep, label):
    jobs = [j for j in jobs if j[0]]
    total = len(jobs)
    if not total:
        return
    done = [0]
    lock = threading.Lock()
    rep.status(label)
    def work(j):
        url, path, sha, size, opt = j
        try:
            download(url, path, sha, size)
        except Exception as e:
            if not opt:
                raise
            rep.log(tr("skipped", os.path.basename(path), e))
        with lock:
            done[0] += 1
            rep.progress(done[0], total)
    with ThreadPoolExecutor(max_workers=16) as ex:
        list(ex.map(work, jobs))
    rep.progress(0, 1)

def ensure_vanilla(entry, rep):
    mc = entry["id"]
    vdir = os.path.join(VERSIONS, mc)
    jpath = os.path.join(vdir, mc + ".json")
    if not os.path.exists(jpath):
        rep.status(tr("dl_ver", mc))
        os.makedirs(vdir, exist_ok=True)
        with open(jpath, "wb") as f:
            f.write(http_get(entry["url"]))
    with open(jpath, encoding="utf-8") as f:
        d = json.load(f)
    c = d["downloads"]["client"]
    run_jobs([(c["url"], os.path.join(vdir, mc + ".jar"), c.get("sha1"), c.get("size"), False)],
             rep, tr("dl_mc", mc))
    return d

def download_progress(urls, path, rep, n):
    """Скачивает большой файл с живым прогрессом. Таймаут на каждый шаг 20 с, источники пробуются по очереди."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    last = None
    for url in urls:
        for attempt in range(2):
            try:
                tmp = path + ".part"
                with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=20) as r, open(tmp, "wb") as f:
                    total = int(r.headers.get("Content-Length") or 0)
                    done, t0, ui = 0, time.time(), 0.0
                    while True:
                        chunk = r.read(1 << 16)
                        if not chunk:
                            break
                        f.write(chunk)
                        done += len(chunk)
                        now = time.time()
                        if now - ui > 0.25:
                            ui = now
                            speed = done / max(now - t0, 0.1) / 1048576
                            if total:
                                rep.progress(done, total)
                                rep.status(tr("dl_java_pct", n, done * 100 // total, done / 1048576, total / 1048576, speed))
                            else:
                                rep.status(tr("dl_java_mb", n, done / 1048576, speed))
                if total and done < total:
                    raise IOError("incomplete download")
                os.replace(tmp, path)
                rep.progress(0, 1)
                return
            except Exception as e:
                last = e
                time.sleep(1)
        rep.log(tr("java_mirror", url.split("/")[2]))
    raise last

def ensure_java(major, rep):
    n = next((x for x in (8, 11, 17, 21, 25) if x >= major), 25)
    d = os.path.join(RUNTIME, "java%d" % n)
    exe_name = "java.exe" if IS_WIN else "java"
    def find():
        for dp, _, fs in os.walk(d):
            if exe_name in fs and os.path.basename(dp) == "bin":
                return os.path.join(dp, exe_name)
    exe = find() if os.path.isdir(d) else None
    if exe:
        return exe
    rep.status(tr("dl_java", n))
    arch = "aarch64" if (IS_ARM and not IS_WIN) else "x64"
    osn, ext = ("windows", "zip") if IS_WIN else ("linux", "tar.gz")
    urls = ["https://api.adoptium.net/v3/binary/latest/%d/ga/%s/%s/jre/hotspot/normal/eclipse" % (n, osn, arch),
            "https://corretto.aws/downloads/latest/amazon-corretto-%d-%s-%s-jdk.%s" % (n, arch, osn, ext)]
    z = os.path.join(CACHE, "java%d.%s" % (n, ext))
    for stale in (z, z + ".part"):            # остатки прошлой неудачной попытки
        if os.path.exists(stale):
            os.remove(stale)
    download_progress(urls, z, rep, n)
    rep.status(tr("unpack_java"))
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    try:
        if IS_WIN:
            with zipfile.ZipFile(z) as zf:
                zf.extractall(d)
        else:
            with tarfile.open(z, "r:gz") as tf:
                try:
                    tf.extractall(d, filter="data")
                except TypeError:             # старые версии Python без filter
                    tf.extractall(d)
    except Exception:
        shutil.rmtree(d, ignore_errors=True)
        raise RuntimeError(tr("java_bad"))
    finally:
        if os.path.exists(z):
            os.remove(z)
    exe = find()
    if not exe:
        raise RuntimeError(tr("java_fail"))
    if not IS_WIN:
        os.chmod(exe, 0o755)
    return exe

def run_proc(cmd, cwd, rep):
    p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         creationflags=NO_WINDOW)
    for line in iter(p.stdout.readline, b""):
        rep.log(line.decode("utf-8", "replace").rstrip())
    return p.wait()

def ensure_profiles_file():
    p = os.path.join(ROOT, "launcher_profiles.json")
    if not os.path.exists(p):
        with open(p, "w") as f:
            json.dump({"profiles": {}, "selectedProfile": "", "version": 3}, f)

def install_forge(fver, java, rep):
    path = os.path.join(CACHE, "forge-%s-installer.jar" % fver)
    rep.status(tr("forge_dl"))
    download("%s/%s/forge-%s-installer.jar" % (FORGE_MAVEN, fver, fver), path)
    ensure_profiles_file()
    before = set(os.listdir(VERSIONS))
    rep.status(tr("forge_inst"))
    code = run_proc([java, "-jar", path, "--installClient", ROOT], ROOT, rep)
    new = [x for x in set(os.listdir(VERSIONS)) - before if "forge" in x.lower()]
    if not new:
        # возможно уже был установлен раньше
        short = fver.split("-", 1)[1] if "-" in fver else fver
        new = [x for x in os.listdir(VERSIONS) if "forge" in x.lower() and short.split("-")[0] in x]
    if not new:
        raise RuntimeError(tr("forge_fail", code))
    return sorted(new)[0]

def forge_installed(fver):
    short = fver.split("-", 1)[1]
    for x in os.listdir(VERSIONS):
        if "forge" in x.lower() and short.split("-")[0] in x and os.path.exists(os.path.join(VERSIONS, x, x + ".json")):
            return x
    return None

def version_installed(mc, loader, lver):
    """Скачана ли выбранная версия: файлы игры и профиль загрузчика уже на диске."""
    if not mc:
        return False
    if not (os.path.exists(os.path.join(VERSIONS, mc, mc + ".json")) and
            os.path.exists(os.path.join(VERSIONS, mc, mc + ".jar"))):
        return False
    if loader == "Vanilla":
        return True
    if not lver:
        return False
    if loader == "Forge":
        vid = forge_installed("%s-%s" % (mc, lver))
        return bool(vid and vid.startswith(mc + "-"))
    if loader == "Fabric":
        vid = "fabric-loader-%s-%s" % (lver, mc)
    else:                                   # OptiFine, lver = "TYPE_PATCH"
        vid = "%s-OptiFine_%s" % (mc, lver)
    return os.path.exists(os.path.join(VERSIONS, vid, vid + ".json"))

def install_fabric(mc, lver, rep):
    vid = "fabric-loader-%s-%s" % (lver, mc)
    p = os.path.join(VERSIONS, vid, vid + ".json")
    if not os.path.exists(p):
        rep.status(tr("fabric_dl"))
        os.makedirs(os.path.dirname(p), exist_ok=True)
        data = http_get("%s/loader/%s/%s/profile/json" % (FABRIC_META, mc, lver))
        with open(p, "wb") as f:
            f.write(data)
    return vid

def install_optifine(mc, entry, java, rep):
    typ, patch = entry["type"], entry["patch"]
    tag = "%s_%s_%s" % (mc, typ, patch)
    vid = "%s-OptiFine_%s_%s" % (mc, typ, patch)
    p = os.path.join(VERSIONS, vid, vid + ".json")
    if os.path.exists(p):
        return vid
    jar = os.path.join(CACHE, "OptiFine_%s.jar" % tag)
    rep.status(tr("of_dl"))
    download(OPTIFINE_DL.format(mc=mc, type=typ, patch=patch), jar)
    out = os.path.join(LIBS, "optifine", "OptiFine", tag, "OptiFine-%s.jar" % tag)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    rep.status(tr("of_patch"))
    vanilla = os.path.join(VERSIONS, mc, mc + ".jar")
    code = run_proc([java, "-cp", jar, "optifine.Patcher", vanilla, jar, out], ROOT, rep)
    if code != 0 or not os.path.exists(out):
        raise RuntimeError(tr("of_fail", code))
    libs = [{"name": "optifine:OptiFine:" + tag}]
    lw = None
    with zipfile.ZipFile(jar) as z:
        for n in z.namelist():
            m = re.match(r"launchwrapper-of-([\d.]+)\.jar$", n)
            if m:
                lw = m.group(1)
                dst = os.path.join(LIBS, "optifine", "launchwrapper-of", lw, "launchwrapper-of-%s.jar" % lw)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with z.open(n) as s, open(dst, "wb") as f:
                    shutil.copyfileobj(s, f)
    if lw:
        libs.append({"name": "optifine:launchwrapper-of:" + lw})
    else:
        libs.append({"name": "net.minecraft:launchwrapper:1.12", "url": "https://libraries.minecraft.net/"})
    with open(os.path.join(VERSIONS, mc, mc + ".json"), encoding="utf-8") as f:
        parent = json.load(f)
    prof = {"id": vid, "inheritsFrom": mc, "type": "release", "time": parent.get("time"),
            "releaseTime": parent.get("releaseTime"), "mainClass": "net.minecraft.launchwrapper.Launch",
            "libraries": libs}
    if "arguments" in parent:
        prof["arguments"] = {"game": ["--tweakClass", "optifine.OptiFineTweaker"], "jvm": []}
    else:
        prof["minecraftArguments"] = parent.get("minecraftArguments", "") + " --tweakClass optifine.OptiFineTweaker"
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(prof, f, indent=2)
    return vid

def link_shared(gamedir, rep, shared=True):
    """Общие (junction/symlink) или отдельные для версии папки mods / resourcepacks / shaderpacks."""
    for n in SHARED:
        target = os.path.join(ROOT, n)
        link = os.path.join(gamedir, n)
        try:
            is_link = os.path.lexists(link) and \
                os.path.normcase(os.path.realpath(link)) == os.path.normcase(os.path.realpath(target))
            if not shared:
                if is_link:                      # убираем ссылку: у версии будет своя папка
                    try:
                        os.unlink(link)
                    except OSError:
                        os.rmdir(link)
                os.makedirs(link, exist_ok=True)
                continue
            if is_link:
                continue
            if os.path.lexists(link):
                if os.path.islink(link):
                    os.remove(link)
                elif os.path.isdir(link):        # обычная папка: переносим файлы в общую
                    for f in os.listdir(link):
                        dst = os.path.join(target, f)
                        if not os.path.exists(dst):
                            shutil.move(os.path.join(link, f), dst)
                    os.rmdir(link)
            if IS_WIN:
                r = subprocess.run(["cmd", "/c", "mklink", "/J", link, target], capture_output=True,
                                   creationflags=NO_WINDOW)
                ok = r.returncode == 0
            else:
                os.symlink(target, link, target_is_directory=True)
                ok = True
            if not ok:
                rep.log(tr("share_fail", n))
        except Exception as e:
            rep.log(tr("share_err", n, e))

def prepare_libraries(data, rep):
    cp, seen, jobs, natives = [], set(), [], []
    for lib in data.get("libraries", []):
        if not rule_ok(lib.get("rules")):
            continue
        dl = lib.get("downloads", {})
        nat = lib.get("natives")
        if nat and OS_NAME in nat:
            a = dl.get("classifiers", {}).get(nat[OS_NAME].replace("${arch}", "64"))
            if a:
                path = os.path.join(LIBS, *a["path"].split("/"))
                jobs.append((a["url"], path, a.get("sha1"), a.get("size"), False))
                natives.append((path, lib.get("extract", {}).get("exclude", [])))
        art = dl.get("artifact")
        if art or not nat:
            key = lib_key(lib["name"])
            if key in seen:
                continue
            seen.add(key)
            if art:
                path = os.path.join(LIBS, *art["path"].split("/"))
                jobs.append((art.get("url"), path, art.get("sha1"), art.get("size"), False))
            else:
                rel = maven_path(lib["name"])
                path = os.path.join(LIBS, *rel.split("/"))
                base = lib.get("url") or "https://libraries.minecraft.net/"
                jobs.append((base.rstrip("/") + "/" + rel, path, None, None, True))
            cp.append(path)
    run_jobs(jobs, rep, tr("dl_libs"))
    return [c for c in cp if os.path.exists(c)], natives

def prepare_assets(data, gamedir, rep):
    idx = data["assetIndex"]
    ipath = os.path.join(ASSETS, "indexes", idx["id"] + ".json")
    download(idx["url"], ipath, idx.get("sha1"))
    with open(ipath, encoding="utf-8") as f:
        index = json.load(f)
    jobs = []
    for name, o in index["objects"].items():
        h = o["hash"]
        jobs.append(("https://resources.download.minecraft.net/%s/%s" % (h[:2], h),
                     os.path.join(ASSETS, "objects", h[:2], h), None, o["size"], False))
    run_jobs(jobs, rep, tr("dl_assets"))
    game_assets = ASSETS
    if index.get("virtual") or index.get("map_to_resources"):
        game_assets = os.path.join(ASSETS, "virtual", "legacy") if index.get("virtual") else os.path.join(gamedir, "resources")
        for name, o in index["objects"].items():
            h = o["hash"]
            dst = os.path.join(game_assets, *name.split("/"))
            if not os.path.exists(dst):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copyfile(os.path.join(ASSETS, "objects", h[:2], h), dst)
    return idx["id"], game_assets

def extract_natives(natives, ndir):
    os.makedirs(ndir, exist_ok=True)
    for path, excl in natives:
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if n.endswith("/") or any(n.startswith(e) for e in excl):
                    continue
                dst = os.path.join(ndir, n)
                if not os.path.exists(dst):
                    z.extract(n, ndir)

def build_command(java, data, vid, nick, ram, cp, ndir, gamedir, idx_id, game_assets):
    root = data["_root"]
    cp_all = cp + [os.path.join(VERSIONS, root, root + ".jar")]
    v = {"auth_player_name": nick, "version_name": vid, "game_directory": gamedir,
         "assets_root": ASSETS, "assets_index_name": idx_id, "auth_uuid": offline_uuid(nick),
         "auth_access_token": "0", "auth_session": "0", "clientid": "skl", "auth_xuid": "0",
         "user_type": "legacy", "version_type": data.get("type", "release"), "user_properties": "{}",
         "natives_directory": ndir, "launcher_name": "SKL", "launcher_version": APP_VER,
         "classpath": os.pathsep.join(cp_all), "library_directory": LIBS, "classpath_separator": os.pathsep,
         "game_assets": game_assets}
    if "arguments" in data:
        jvm = collect_args(data["arguments"].get("jvm", []))
        game = collect_args(data["arguments"].get("game", []))
    else:
        jvm = ["-Djava.library.path=${natives_directory}", "-cp", "${classpath}"]
        game = data.get("minecraftArguments", "").split()
    def sub(s):
        for k, val in v.items():
            s = s.replace("${%s}" % k, val)
        return s
    cmd = [java, "-Xmx%dM" % ram, "-Xms512M"] + [sub(a) for a in jvm] + [data["mainClass"]] + [sub(a) for a in game]
    return cmd

# ───────────────────────── интерфейс ─────────────────────────
BG, CARD, FIELD, FG, MUTED, ACC, ACC2 = "#101016", "#1a1a24", "#262633", "#ececf3", "#8a8a9c", "#4ade80", "#22c55e"
LOGO_ICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAeYklEQVR42u19fZBc1XXn75z7+vXHzGg0I2kEwhCbT1syshyBBxubkQyyYjuV2HG1EkgCC5Rl4ricsNrdfFSlRrO7Tu1Wkk2qUqvs4hjDWrax2oDB8hYx2NKAXXECirAAYRghiQ+NEJJmmNHM9Md79579473uft39uqd7ZrppeftB16hfv9Pv9vude+6553fPuYRmHgIaxjDtBxgABlKHJbUtpdE5ajyzYR7a7z+v04cllUwZEKRZt6NmgJ5EkoEkUrQtFOzrXrs7vkIGYlNTU23wxMvb0Btyzj9V5aNFH729mD7p5A5t/ZvZsI+Te5IKSSCFpVeGpVMAERrav1ONbh5xCw1/ftieiuj3Gca1JPIBI3IljFwEkeUg6oIxlb9GJHCOAEj+/4KG5d+YgEzg0/BzpuRT719Sdq7sffFWJuScoPKPlDWitL1V2+b9zDQgUyA+CaYxIf1zWJGnxWReOHDNPXP564f2DVuj+2EwMmLaQwEElMQezvf2jc9sj6zsX/1xMfgtMfJxiFxu9dgQAOIKxDUQ47+kFvgIAb/48KQSyernQoGufU7E/ycV0RPJP7EyUPPXSeAj8r+khoJI8BomEBOg/L8E6DkHIvKaiDxFwEMS0Y/llSEpSbUUFmFRCpCUpEqRN6ZvOTI8wCy3GZHbOKLWscXQaRcm50AgrvcAiQAhIoGY/L39Xg4JgECFJ17ZmaTGNVRArohn4PvLrikCWLwGIEgB6eC5oMLkFZNQrgkSlPO/VwJtzT9yKdWyfPt8dfDuRkIKESaOWoAIdMY5Rop359LZrx8a+sdj5Ri0TgECvX5o3xe7o5es/COCfJm77AGddqDTjiGCAYQFxOUoSjmqpVaxvp4fag3mMfFVrUNYO2pYjCpDUvVzUj6ylP/g8HPe2GVEICACR5TimAU9l5sG4at6IvPfn/3U109DhhkYkYVYA25UYFiGGQRJ0Ta9dewvfjP6KysPWF2R/2pEBpzJOdcDnxiA1QF/seALAGIiUiRQJucaZzrtipFlKh7ZofrjBz/407vuAI0YECS5J6maagGSskelaJve8k87uviyxN9y1Pq8cTV0xnEBKICoAHSIM9QBv1Hww4a+/KMUTZayOG5BZ5yH9fTMXYe27n5raN+QNbp51F1yCzC0b9hK0Tb98ef/bC1f2fVT1R39vDOb1TrjGBBZHfBbBH6x41riuOKey7gqGvms1dvzL+v33f7R0c2j7tC+YWtJLcCQDFujNOLe+NyfbLK6Yw+R4j49m3GFyCp3vzvgNxn8SmsAEXE5qiwQcm5a33Zo81cf2PjM9siBa+5xFm0BhvYVwVfd0R9ApM+dyegO+O0Bvt+NLZ3TWhwTsWLWt9fvu+N3Dlxzj1OPJaB6pnk3Hf6zIY5H/i8MEibrGDBxB/z2AL/knBEDRaCIYj2bu/nQTfc+MJ9PwLW8/RSl9Oaf/8erVCzyCEkH/LYFvxBOIBZtYBxtOB755tU/uuOG0c2jbq3Zgao2zx9IDfC6v9kayyH2BEcjF+u5nAaT6oDfhuAH0SAi0SKkmIjpUytuvXr36Ke/NQMMM0ZHpS4LkMQeTm1L6cmZ+N9HlsfXuTMZtwP+eQC+f46I2GQdw3FrtRLrfhAkufMw1TUEeOP+Nn3TS3/+6ciy2J3O5JwL7jh85wv4hfdMyp3Outay6CeufvyOL6YopcOGAlUZ4k2iZ/umuJuVHxCh17iaQERtC3450PWQP1KhPvOAHwJ0PeBXPiifZ0Bzwc9bAhBBGxHGDStvW3/f6Ke/OQOgZCjgctM/QiMmM+3+sb08/m6dcTQoGM5tE/CNIMQGhFCxgJg8dxx2dRXw899vJMQ9qnJLY0ruE/LrKthPMdI08P05HhnXGNVlL2OX/wuIJLmudCigQOsIINx44k/7eUaNIUK94mhAfK+/jXo+xSyYjOvR9FS753NUwWRdwzHFJqMhJkDpVun5HFXQWddw1GKTzd+nds+nqIJkXUNRi01We4pAtXs+ogzJugYozqyWDPwCvwiPJFJk4Mr7n7vx3pchwwTy1hMUAgXeYg646iV1u7U81pebnHMBf+xvo55PiQhOf+dFnPnOi+CYVdmtCqpN0HMuln/i3bjoP1zLp/7xEM5+9yVwzArt2YAHg55z0bvl3bjw7o381r3PYeLBMXBMhXd9/z4m7WLZjZdg9R//Kp+57wVMPjTmtc2E2QGA2JPpufFirPz81aynswBRM8AHABIj2uqJWu5U5ssA/jCJw5yqtACgjQe2W31dK5/nmHWFTjvisXrt5vARXrrlUaTHJqASkapggiAEkM66E1d9+9fH3vjKvw7O/vyUqC6bgsNBWShMAJDO6onLv/XJsZNfeXpw9tBpUV0Rqqpovt+ts+7Ee76xdezUfzswmD50WrgOGZN1Jy75+pax+JX9g+5sToiJlhj8ovmxGMbVb4urLj/8a1+bgIBAEM57/iDIisSKTarLvrJ9wfeu4ZgCJyKgqAWOW+BYyCtqgRM2iChz5vEjKY4pcNyToVjgFS195WUmnziS4pj3/eXXVMpEQEyZyR8dTXFUgeqR6YoARJmp0aMpCerhUoMPQAhkHG2snlgfWfq3PIs/pApO4Fv71xIAaMI2tlgIMG3p7UuB/fDMa/Bv2Msbh5njti21riuXgTAWIEMLkYnaduG3NwP8/DkiiDFCgiQAjG7aZPIKQKObR9yNz2yPQHCTzrgkEG67nh86mtZxiDcINi7XYplmgu9ZGJa0SwZy/YYnb18FGjEQEA/LMAHAqu4V72PFv2KyjpTO+9swyLOQo2kr65fgkNJVi0sNft7bMa42Km53ZTNyLQAkU0nm/f4w4Br6kNVtk0C0v4qx7cBvKZCmZUJVl5QvHfgC8RbPGoowiMxHAODoZB9b2F9o/K8KnQ/h3cY1oJ1TkUxLwC9MWUm0AQx9EAAO9E0a3rTJa4MhukJc4y/dbufY/i//0RTw/ZmxOAaAXAoA2JbSPOJHhEhwodHGmzS0bc+XQvAlcGKeF5mFy6A195HqYC8V+L65IdEGAlp51fd+o6cQCRw6NhyTuWyfaPG0RKitiR2TccFMRFRzQROBCCB0gYkl64KYuC4ZLpUBUa2lU8X7mEoZqaNt1fyAJQU/n0CjBUTSY0l8OYBzFgBkZ5FI5HP1QqISTSd2mOojdlwD7raxbNMl7ql/+LezVl/MrjHzMqQU5zLpvfaaxHhk6GIzc/DNU5ZFMcwj46bTe9Wa+Hj3De8yswdPnVIWxWrex/Jk+KL4ePfHLjJzz9YhI4rdTHavsJwAASARPx7cPPDzqWhEUSce6ypYAMtkhZSIiGo9sZOI1E/sJCJistpc+KUPaurnXWcfe/mAEGLI6dAnzbaixLWrx7uuGNiR+PWVMFF31+QTrxw0BjHocBmxFcWuXT3ec/nAjvinVkLbZtfUjwMy5R6lAkQpim1YMd5z5aod8U+tgGvrXZNPHDvIrGM6F2IEFAClyFq//GTvde+6uzINsQngl6ifgEQXdAIfPfSnfbaSo2Sp5eIYAXljQDsROybtYvnW9+CCP9gAPZMDiESMmZT8eFWN49cSVYlIQhztxRCNmRQQFSJyFTSvAL6McQ1ERESbyXxsRMSU8gji07rGRFXCTsAx3iljJhFoW+j4rk1UdUUSJquba/ZLhUgIMFq/96VPfvMlq+qstNljPhNMRuPMd36B9NhkHcQO0cl/+LeJ7hvWjHVduXLQnXPANvcHkndBpVEVjw2yBCbjeOaVQGSpfiod5/zeJ8UvsQCdcb13BOKI6i9EVKU0p1VE4C2WU5CsKxAiISFW3F/O8ROVOXwWwaRdL/DWip4fkmISqgAVTmCLiB0K+bEFHbAYJudmJn50JJW4atUgQcRfrxDiQJVl6VLRNYejpXaWbn5xZcATcoxI2TVF7j6oTESSH8ZcI7VX+/hyrQI/VCHKFUCk0glstrdfTuhUdZsEIGGO27a3qsN7ehUTFkJZIJPK5xUEKgOfUKYQlXRC8BrfkJbyyZVgl04dpJx+ptaY/fChoOgnVRdsc2Lnl2kBZ6t7fkCQK+Gg84LY6YC/wJ4vgqDV5GpPt22JHdMBf+Fmv/I6rpzTSEt6viw6wN8Bf8Hgh/oA5xWxU8Wn6IBfX8+XsFnAO0XpEtWjEnkWyJS0lzrgL6jnU/H7rbIZFIpVtJrf88uJHamDcCH2ElU6PX8h4FfiWhkI8ufFTc/V0wLuimDZDRe7p+45eNay8sQOVSFPhN1Meq+29AkQQQr/d8BvGHwBkK1QgLwDWAZCsxI1iWAyrqz5Tx/SNBDZdfbRXxwQrk7SkK2o53NXji+//rK7C6wWqAP+Qnq+AIiG+ACoEjBoSpauCNhWdGb34ejUQ8d2qpw1ySIECSlZwARzNocu6Yl3r1sdc07PwC9F1wG/0Z6P0v5tVXpa1HzwIQADJmdw+tsvIntkklRPtL9mKJgIZ3a/OLXspkueTbx35XV61hEwUQf8xsb88ncciK+UxuebCX7+X0a8LJ54BFAksKq8FBmyWaDNzNv7jn23qMId8Bsy+/M6gfkITUk5gCaAL2XK5ZfGrTkZFBAYCnHbFgl7wB3w6wZfAORCyKAgUdnUnr/QWLAgkEkjHfAX2vOlJhfQZPBlMUQA+WRAB/wF9/zg2rNyBZCyQFDTwQ/xShsOCHfAb2DPhBpO4DtbkKkDfivBl6pDwHw7bbQT+OiAvyDwq5NBUvXLmwe+LJAMkvLleR3wG8GHUJgGWDXsa/PBF8DPpKk/y6dsE4oFlWILq7NbFVgJWcdyfpv94JvKSKBQiZfYNPB9Mqhn6GL3rf/97Fm1HDbqyKQhJSd8lQijrUJLsXmTBy8DqQLEMPCNHwsxEjJPqrLY2khxy4R2Bt8/ly1XgOLsoEUVOImgM1pWf3GDRh/tmvzhkQPzZuxsXHVy2fXvvpvjEei0U1cpNor55dviFktWe7NIqt3zKWbBZF1DcVWQ8VStes+nmAXJagOA2x18CfUBDAAV2CWrmeD7hgbGkGQluuqz63au/M33zZ+x45iotTKROLP7MCYffJnrKsX28Yux6ssb+Oz9hzH18CugkpJvlWEGSbvo2nwxVn5pPU9+40VMP3LMlwn3XIXJl3kX+u54X6HkW1uCH/ITSulg0AK+fBG1d8nbS7D+jB2GO5WRyQdfptzRKVCtdDLfwzx97/MTiRsuHDv32KuD2VfeFk7MX75t4r4XJuIfWz0288PX65AhAUCT9x2eiH94YCx6Rd+gCRBVbdXzQ1pvhXeDFoAf8OTrz9jxO3fU8kqx2TUVAKQYxtGZqSeOpihmDebLwtWWIRhHZ6b3HUtRVA1yLDK/jMUQR2emnno1NXBF32C7m/0gClaFAyVSNr1qIvhoIGMn2JhGsokgTAnbczAFdcj4hj1m22JmSku7zXefmG0Hm9h+4Ff+Bq5G0LRdyfXFhI4aLN9GC5Ap3iesAHR7gR8eCTyf6u2jfQ8RlJdpbR/wS3evDSrA1PkDvpxH1aLaDfwQE1BJBwu1MfgLwyFfiYk64FfYT6tW/LzT8xdLWLUp+GGBoKLzH9wuvU17/kIIpFbJiFeVsyQY1C7gV+KfV4BeAJk2NvtlrF5Wg5io7lJsIJaMLpRvq5d08u/TgIxfZLsa0NXOvUPgBxRgCvlMgaKX2H7gixFw3ELXxy50z37t+bOqF3Y95dusi+LjkY+uMXM/f+uUsuCXiauSgWQxO+nsXl4TG09cf4E5W4+MCOt0dq9YOBEIqFLots/Bc6Ys5tIy8GsFgsr6VDv1fAAwWVdWbb9a03K16+wPjx6YtxTbhhXjiUtX7Ihv7Ydru7umfnz0IDNiukppOdhE1oa+8a7LVuyIbV0BHXV3Tf34+EHh6uXoYBPx+uUnez500d0UV0DGI6oq622Wmn2KKkjONYLgbqwtAL98w5SPHvqDPpONHqUILxdHS766TVvuqydeuFak/lJsnIgkvBq5EBiZFDGEilsE2q7Fl/FKy8GYSZH8M5HKHi0AXBNV/fHEuQdfwcz3j4OiqvR3BcWYIGmN+NCF6LntSpjpHIolxJoIvhTtu4G89/hnUi9ZlVRQFSewXcqy+ARSI6XY8uXbQCAo6qf8dokBpQmOemQJTNYpyJBS/fktnSiE5iV4RJWZzsnMo8fJOX5uXqKKCDT1jZcm7MFVY/ZlywdlLidgolaY/SqJIQb5fSTbfkfNRkux+d6iQAA3aJvDqmbkzxULBIurRcpDaGFkD4Qoxj5RpeYlqiinMzM/eT3Vf1nvYCvMfh1l4grbB7Yv+IstxRYENkQmdKucAFFVMq2jkPFd0BhRFSO7ULipZeBLSGYQGt1O9R0Gv50WcEIWUfGMpHU9Xyow4jIqoAN+o+CLLA05JS3o+ZX4l9PBEq41HfAbqMPXruCHk+qMjtlfwp4vC+7+Qq0Hv5INlCBn1gG/sZ6/yKGgleCH5gVIeRHnDvgLonQXQCAJAjPWZoIfMiuxymgN+AvnO+AvkM+XnAYRUb0EkpRkOrUG/GBEozISKCjLt+mAXxf4RkBxC7HBVe707rGzbEVrZzopn0BifYKI/NkgUSvAr2IBpLA4twN+4z0fACTrSu9d67T0qV3nfvTqAWEdQy58ONA2EX9izXhi8KK7QRKew98s8ANRzcpIYAf8BYDvz/8iimYeOhbN/tObOyNOZBISnlAiTMCUiygvi8evWhFzz6QBv+xda8BHFSewrAEd8BtYyUMEOAazjxyH8+oMcXekv+oQ4PsHcw8fn4p9bODZyGV918mcI2BQK8GvnAZSp+cvCPwAn0Yxy8slZBKoKi+GoYhX9u7cT09+t/I5NRf8QJGwyj2D4JNBHfAbAL98DyQppaSqTAQJBMUxZRd4ZqGWgA8Atp8gzuiM+Yvv+ah2br5QAANGS75trQI/PC+gA/6SVuCs+1DlHEITwZdKzDhUhzvgL3LpdgOHRmBtQZPBnzc5lKRThLGV4FcJEDcb/KATGFImjjrgL1ERxvoOrkLaNA/86mXipNPzFw0+1aUJUpw4mmJ7qcnghyiqFdqyloO/iFJs1ZZpNwJ0tXN1F1wskjiSM4WspbrIIOWTQS0Bfx42UPJbsVDrwF9QKbZCSfs6lmTkFwGX5OvVmbEj3srwuhTCFVCXhejgKndm95Gz3GvbNRaFGihmnc7uNSwnihSyUHN7PqorQKEgE6S2H7DEZp/iCo2WYqOYxSbrFmRq9XzEFJB1DcXyZeLqz9hBzGIU2la751NcieSM6bn1Ci29tGt23+sHxM9aUp6zXzr7sw3ptV0nuzauuRul+Dfd7FeUiXNVjoAozesELnHPp7jC9CNHMf3w0fpKsW26CCu+eDW/vfsXmP7+8drFmwiQjEZiaA2W37WOp7/1Mmb2vlpfxs4NF2DZ9rV87oEjmPvBawUZqRLXl4yL2A0XUs/vXa7MrKO6f+3SnV2feM8kAhlIoUEePwPJpB0AxC0DnwAhr20WAMydy2btbjtNRL2tGvPBXpbv9MOvIHdsep5MGr8U2/0vTsSvXz028/iJwdwr0375NhMkMspHA3r7//xiIvqRgbG5J04MOq9MC81TJo4INLV7bML+8MBY+sfjg86xaaF4DRnygufndr88EfnQijH70t5BzLngCPcDqiBGZRYD8DKQJOt46wBaCb6YnJBJF+Ygh7bungVokizyDGnTvf2gufVLvkVrvRQ4YYGIMlP7X01RTIFj3vngNeWvvMzMk6+mKKr8+3DotYVX3AIRMjNPHU+RrUAxVVvGZlA84t3nJ+OpvFKIa8Q4RsTNv3TZOe89yr3FZoIvvr9lMNOdNpOeAsgw+5bsFJir+CBLPNULhj7LS75VewVLsdVzfYlMxEsjr1uG/PuY0tJyoS8U7lMgdjwvg4r/+e9Lznnvw7boac6YLwCJkGIQ4eyR33vsHADw0H7PCojIEX8nPmn6PL+GLz5/tGwh5dukyTLvELHTCPj5D7zM6uMgCGSYGZsK1x4Ual2QZ+GxU7NEcdcmHK0mdhoDHzAkYAYYzwIA7tmrrNF8ES0HT5s5ByReyehWR/gWEjNvSGdacbxDxE5d4AsgIkTagCD/DAAY7xYGRgQAumTuOcnpcYooAoxpOvi/7Ee7ge+Zf6XnnCy5+Bfvg1HDIEhS9qjRzfdnhGg/RS2RYmm95vX8FuqBadmdWkzs1A8+IMZQVAmR/Ovrtzw6juFhxggMA8Bb+1/wR3+zByIEyacINJ/YkWImTR2vivJtTZLxdYbQoEyR2Gkr8P04L1lMMHgQALBpPxdUdnTTiIaAIpz4oTuTfYNti6UYYWkqqxco+Vbrxd7fQPk2RexNpuaXkdKSb/XLeMRO/TItJXYaAR8CJmVmcrPKVns8BRjVRS6AIEP7hq3RzSPpjT/5wtc5Zv2FzjmaAtWrlhx8I+B4BInrL3Dfvu/Fs9yb3zOodvk2WhMdj3/kApM5dPoU90VjpXxAicIaWB7hYl0YGVcfHjBvP3fmFCu7ugxgSDHrdGYvDUTHo4MDJvvcWU9G0GbETt3gAwLNCcvSM7mHX/vcwyexJ6lAKV1CBo3u9x5LztH32DPZHcwcEy3+etVm8PkEk9XSf+daLX20a+qJYwfmK8Vmbegb77p05Y7Yln64Ub3r3P7jB0Wq7zMEm4jX9Y3HL125w97SByeid80+9VqpjC6dxmlFxOu6x+OX9+2IbumDE3F3pZ9842B7Ezs1wPedE5PVIob/rlz1S94kZY9K0Tb9wSe3/3WkN77DeTvtgkqTR5YG/EDr/ZJvdZVi0xLleCQhrgEgXpm4YHGzMI7fmCjF8jIQ0WYSBCrdgdz4MXL2JkAGUY5bCXGNN3syUjexIzkXbdPzAUCLph5b6XO5h07e8ujnsCepsC2lQ9cDpLDNYHiYo9Ybf5k7l7mVbLVCHNcE9+pb0pU8BCC/Z1BdpdgEknMFAhICsVL95Q+YKh46+TJEICG2uL/0HgLxvXcSAMqr1iQ5V8QvE8eK2pPYqW32vcsiBMm4WWXJn0BA2LlWqlqAoBXY8NQXbrV67Pvd6YxLQtaSg19pDeouxVaCXY0CCGXVBfMfSfXVPaV7mga93zp34yC0MrZfG3yIiMvLbMtMZ4bHb977n8t7P6q5Qsk9SZXaltIbRrc/YvVEf8OdzhSHgl/ijZRbmZ/fdPCNaEpYSjLugStWT103enpAkEwZlLkmHKYAqRfWCoaHORKL3KHncm9wVFlS5vt0wG9j8CEGESJxzSyEbxndPOoiuVbKwa+qABgZMcl1h+npwf951nGdbQJyWBHBiOmA3+bgiwiIDNkWm7Tz78Zv/t7L3rRvJDQgWnPp6tC+IWt086i7/vE7f9vqth8wjmtEGy+XvQN+e4LPpDlhWe657L9/85a9f4t9QxY2j7rzBK/Dj9HNo+7QvmHr0JavfcfNZG+miGIoJqliCTrgv8Nmn2A4YVlm2tlRD/jzWoD8sfGZ7ZED19zjrH/ijt/hRGQ3DJTJOS6IrA74beLwWaQQVZAZd8f47z76P+oBf14LkD8OXHOPM7Rv2Dp0070PyJyzBSQnVE/UEiNuMaejA37LgzwCERGXEpYSi6Zk1vntRsCv2wKU+wQf+P6tF6HX/ion7E+a2RyMq12AVCkN0gG/qT3fiBZFirsjMGn3ZyadufPN33/sMIaHLIzUB37DChCMEQDAB0bv/JIwj3BM9evpHETEJUAJlU84OuAvGatnxADE1B0hyblzxshfnZx44yv4wgEnLNCz5AoAABj2VhJjZMSsffz3L7Gi0T+H4HaOW7aey8E4okEACRgk1AF/EeB71KnxniZZHLdgshqA2aMd2vnmzd97sYDJyEjDa18WtZlmUpIq5dOK6/fd8X4oustobFMJa5VogWRcGFcbAYxXPlMIxg/DUxWg6wG/zkRNVAWx7j12QpVhacAPyb0QKebnCYmIEJgURRVIMUzamQbTw4D7v0587vs/AwC/1y94pezid1MVoWRqG+eHhQ1P3r5Ka/qMgD4rYj7CttVLEQa0QBwNo423sttIxxoEPyZ4qy8Ue4QUM6ANTMadA9PTIPM9yeHB8Zsfed0TGmbs9KzwYuBbuu10h4c5ufMw5S0CALz/n+9cjTm9EUQfhuADYuRSEVkNSDeIYzCmMlFTpHT74uCKhJLc1fJzAVDz14iUPOCKuvyBa3wKv3hNi8EXMTmAZohwWoBjAD0HyM+MuM+c3Lb3tYLAnqTywrojS7LUcen3UxbQ0P4hNbppkwlr5OU/+91l8XR8GSkkctksxDX1tyGL/P6WpedCj1ztjxs9co1fbpfdPfQrNAuWATIbydiR3PSrn3lkqiJmLyDsHFLYOarD4vntpQDlwwO28Vv719LA6cOSatBD/f/22JNUWPUWYT8AbDKLNfO1jv8HXOz2vz0Ng+cAAAAASUVORK5CYII="
LOGO_HEAD_B64 = "iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAPuElEQVR42sVba4xdV3X+vrXPuXceHj+TQBLiPFqIZQi4BUxIaUMgiaDwA9pOWqhQ6UP8Qf2BkIpoq1qWKqpKbar+aKSKCvILkF2pRVERbVqModCkgdYmDkmUQBwnduI4Hns8r3vP2Xt9/bHPnTl3PE+nEmPfWfdsn73PXmfttda3HiZW+xF457cPhKN3HYyDoTufOzDSLYur4/z8BKrVJlbD/7TqfcM3VINfndXnlAVnUxXOPXLH3yws7unIncXR9x5NILTSHK40eEAH7CAPOgB8+KkDV/XK9BE6PyhPb5XrGkmjECA1a0p59Q3QTAY0v0l5Q9WiK8yRoUfgHIgTIL6JefzTY3c98HK+4YCh2fOaDE5qMhzm4XT79z8zuvWa8T8S+elirHO1kiP1IxQTPOnyDUHN33XoKkxuZC4IIBAsA2hEXKim4Pj72bO9v3j6I1+amTw0GQ7fdzityuCkDoXDvC/dc+KP99l48WAY67ytnu7BY4wSCIgQ2Txyc5JbceObkfbiXEmQIJmxsC0dxPn6qThT/+7j9/7DIwMBDXiyReYOTYbDvC/ddfxzv2LjxXcY7G3V1FztMQpgQSIANFAUMrMCCK1GQbRonrOcrr4WAGo5hZj3rECg8OiqLyxEGvcUE8WRtz78+x84zMNp8tBkGJLgQOfufvJPbwsj9j25JlIvJhrC8mO4mp4M0zXmbGCtyyS3JgXkSiwZYOx7r7rzR+/78qM4NBlw3+FkzRvG7ac+M0rqawx2hcw1D4sOJYcPaBLkS9eKyjQJWHat5JAL3lx7a3wt/SURvPYEokuzr+5/5A+34om9gkDeeeRAcfSug/Hup/7kzzo7Rg/2X52NNBabZ05gIGysgLxl+SQoCizY6JEgEqoTRIDGxfsAQLUDgZfpa5qvgaSB9rcs+NJ3Tx6LHSNFvLBw/+N3f/mzk5oMBIB7TxzY6UX9Exa21auUdWczx1IAS0N1egYvf/nx/FQS6kd0b9mWujdtx/S/nwwcCQAIX6gxcecNMZ6bDws/Pk+OFIBnbZy4Z3c9+93Tpc/WmdHoCDtGfOcn9oiFBfkii5dbZ0kKFKReVeONT9/7pTMFAHhR/1q5bXR7f2oukbTN6pzcYZ0CCyence5rT8BGS8CVj8iInRm5Zfv0wuNTb0FJhwDUbrM/euUYHTfXL8zuQseyE6iTzz9z/tH6pzPv0XwEjGIg43z/lS13X//y6K1X7YuXeg6jreh6ACp6Ctu6Y+XF3m8BuL/IstWHlXxR5ps3KIA8H8Niaxc2VmaJAEBBZ8fqYkcXCM39SbCO1bCQiu1doOTi8WSwyrZ2gNIAIxgM7hIclZrpXMOvAqBql4BfBXC/fUB/2wVwW+rHbK43xVyjY642o0N/snLSLhsH8/OWjxsNLi1bw50yDHR4VdAgQLJGzfa+/eFPbSviE1Ovk+kaxQSIBDdgUBa9KBtTxuydqiRVbugC8AGK85E4W11AhAGwLEHA+zFQNCTYojdOMM3XrsqJFrpU9DFFpSEJruY2ACAmuLSr10nXFd6ptqBGFyvBr9Ukx+wOvJ/yd89SHN17Fcf27fqv+nzvVZABgjhqL+/69Te95fxXn/43pVSBMtWIY/tf92q5c2x8+hvP/Sc71gEAr+LsxIduCr3jU8d6T557noWVoKHojrwUtnf2wb21x1WZpFwg0FGvnuD7Tnx+L6hjIEq5tHhMV7GWIKDk+Olnv4X+yWnYSAEI8H5MN3zhly9MvPs6pEvVvKAAQXKVoK4WcRaOJIgwJNW+HcYuiLNyNwmg0VX5tQiYA3DJXQGSJARV6Vpo4wCggYfvKpYGuT6mbMy/9xOqk9Ooz86DnQAGIk7Np5nHzhyfeMe171flSyBQgtcOFry25Z2zT0sOFNy95M8yIEDEdhq3Y3izm2JugM2LdgC4NvjF4rEFAXYLsGOZQQPYKWAjZfDo8pgEZh0aHGqvpctgGETUWURDR0yS0mUb5mYgHCTUYMNgdlnrYstBzDJkOeWADIBMkoFifgmkiJZFEvMjGnjdZnJovBXlcNiobVaC5UCCWlOCbaPTLGIEApM8S4USlHwByWfap3DzwLkFv7C5Y7lS8F2zJcGVdXCZT8wmW2Giw2333PjMq4ee/KGNl10kRzk6Pju+//V7FD07gxzibCoq+H9hrrVXZAlWEGwFCa7s8BHION3HpSMv7EFfe4CY8eVc7dWpmefH9lwFuTgA0RtnTlfEHJZLrsUHWMOqlpVaP55rFnNB/ZhpzNbHe3Xdf3Hm2ez8N/v224B5c3NXdGWD63pFHVwrOG0dIaOGkh5msG4oB/CN4OaPJV6bzl0mwUU30dLBoWzXKhQuwEEWBgYDMyjuKnqRA9uWtAeP9eUbWcKybWnkjA+ujLkVdbBqrHxbSmulFxLEkUDbUkzVz8yfZxmMgYy93gzHileKHSMQXCCzkUmCooMdy0e6ebRXCSDB0LLOBHw+AnVal8m1wEg7yhmWINaRIAC4g90Cu+9/70x9sfcsYiolwMaLvubTvjN//gi8HwkjVCV0btzq5Ru2cPa7p8luzgWpFzF6++s9ne9Z/5mLYDdkJt0x8aGbvLh+3FCtzuSaklsK+paQzHCEvI4ESapXo9g2cmPnmvEbpYxNbaLE9MPP45UvHkcY7VDugoMcDWc6P7/tUv/41F4WzCneWjb7w7PHWOum+oXZneyYYKTPV45RPrrzD257t/cisIIlXp+5NSQobEAH1eDRXq3Uq10uwh1MSYpuxdYR2lixGPDKGEn2ix1dtMIi0NjnSIjFji5UMIMHApDmByhpVVew0rFcQYJpEaoNJVY3mNojCSlkf8dsTNkEvElqGCQMUiCV5FATJabGnlBUUmq0g0hKQLCloHbppW9IcsstPiOWogmuI8E18pbKSBOKDtQyji6ZQo8a11w9DcEo2qJhrVLhYqAYcj6XoGheJbaSD0v+ueF4w8w1RmtjElwnKQsA6id0dk+ouGXiB+li7zxLBDjAETs9ce/uW6cPP3vEY6poNNWK3Vu3vVTuGhubffjUo+ywBAF1OVfcPN4HiZwjMso952cAqlbLBazhxgZ81ADf8z+f3eueLg94N5txdoGlwQ0vUZr15AGAy1XCeL3kL0KMgJvIhOg7FDgG4bSnFOACx4tUPzN93dRfHR9XVPaJSbCtZX/75/ZVtqWcUO1aNXe0/Ai73lXkYpxlbLxcaTeTTmf2bSzsWpBoso+5olBFsAg35XutyakQ6DtY2BuNAYKDMvhMRPV04zocYmGsnpw6n87Nvxh27dzv/dj42NWY01CIlXXQAdhrYK7NZJ10uZUDUUWtkCCiBuMuqCmZcLQgi1zMYiA4WhLGVolzLclhaN8ZbGNImYfM8qZDHoIguUgHkTjy9RBdPj6oLPnSfpqgmjns1PrHchkcNFSDdZZlq68oWL3yqABL8f3SZgZL1qok7y3B5Q0wtwi2OwBqNXb+yktYrzkqIOD9pGL3Fpb7dnyvfnb6lIJ16FJ405aL4aqR96lK7Zhg3SQZF8F243OunDm99kjcBXYD65MziE9duoPA7Yx5PV5Mc1pIC9oiyMVsXjdQVSYb8NQKeH8mzA0oAVUJWogGR4GogmQRz/Xm0qXqpyxtUJNbo5SwdF3HehnY/hkmiLJHGRSpF4PpDOkKAkRH7bLBuuGSgKINtrXJHEoT1LaP9WIav30aWgHvspzo8HgSkATEjHMZLBdvc0A92uRLh5HKegFvbEO1TUrQJkrIuBTE5vQ9rBOGq7MxB7zWNTQ1gzzez9lvBi7qILoG21ZCdTwX5+oeADAYU693UtZ6l9ygBBcd/SYlCAAX//knSGcXcm0vASiJ0Xe+DguPncUgda8qoXjDuMK14+w9ehYYBLb9hO4v7lK6UDE+dwnoWBPwSqP3XI+dD/zSKb/YPy2phCQUrMLVI+/xXmwOrtaV4OCnCGWaq119kuXaZr6ZZ4AvRFx48CnEl2bBTrPp5PXID88eq05ceKeqlIGkgxwPZ8pbJmar4xduRUEHAVSyhUfO/AgVdsdTczvQoUBSC7UE/8HWT+3d7/Px7e3Mts/XUJ0GMcZazAkE3VUH+GzR2Xn12erMK68ycIvqZWn1y5JQjb8EYFtKhO1doDQQgEeX6jRj2zpQk2/JdUPVEubCjm6T+8kBL8Q5dFDbjg5QMIdrRiimmTRbuWaq3KywVBG0DTCXvUMgkDQ13eEZO3rzwR6EEyxDRoRruIIlHNgU/JMcST6gCMHgzffBxyEYTWnZOJG5Gh5PMBpIE2kwGkkDETbKHOCOwiTgyemPfv1i8071DQYu1XZXgl/QsBOtnWTeQPMZ8YWaSDCSofkYhC2ajyRoJIvmY6rVQT+FZm6mYKkIw2aa/C4LmygUJKFvLhqZ5OU/6lLvLy1w3GsXCK5YKwCA6OJYyc6ebc/PfvfMswxFSQCq4/TY/mti9d/nTlQvzJyFoQAMKPHC+B3X3DL79VPfU/IKJkNiKq8bfz7sGhvrHXnpf2EoaEYhzvHqzqVGTdSkRTbMHATBYGm27sPxFQBYbAT6he986gvF9tHP11PzkWSxRpegGEiZpjzpNNwDcgUtEbzZoYuQLih6IeaA1wq70VM6KWcU3GAWkXwXCk4g+UlPTaBEJCTdAHK7koZTFKtZy7ZhTIq2tVPES70HXvrYQ5/GocnQNMsd4N5vnxvrhnSM3fBzaaFKBMNa7oJGoLChce9HIDQZskGEoqaOUYYGQjb3Nq1dLG1IEoop53aAjUsu9+okdkLw6GcMndtefGLvReAgDIQOAPjxXQ/Myv1jcu+xsODytJYv9OTyXu2pV/mAyiWvUh7v53H1YrZJ/ajUq9370VOvdtVJcsF70b2fx71fu6LrSpiDmQlKqR9/+8X7Dk/hzT8mDsINAA7yoE8emgzH3vvFx9Js/VEYe9YtgiePuQlglW6GjEVsQJsqbtPySANgTf12UII25VqdqVW2AWi5hkfbuLVsmkeTIjtFQAFPs/E3z37iX7496DRcoSE2N5O++T8+eUfRLR+00fKN8VIfSh4bBGED1Llm8XGDdM3m2JXnaOAK5BQMhY2X8F79PPrp905//KFv4cCdBQ4ejZc1xALAoJn0ifc/+H2cq/bHueqvaZwJ27qFjZUBpeX0wnrFx8tou2LUts5YHTivsBaI7GRGymBby4LG+bhQ/Z334jtOf/yhb+HQZGgzt2pTervB+81HP3mDMfyGR/8ghL1yvwpCd+PtzCv0XusKWqIBOFQBOC/iSYP+tXY/fPa+h54DgPaxXJ/Bps90EpPW7n9+25Hf2Z6A13tfWwdjddPNUKM1Uq+8ZGz9Xu2exVViU55tySMUmFFn7OVTH/7KhcXBQ5MBk4d9tf9W8H8ixacrWG9chAAAAABJRU5ErkJggg=="

def mix(a, b, t):
    pa = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    pb = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * t) for x, y in zip(pa, pb))

def total_ram_mb():
    try:
        if IS_WIN:
            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(m)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return int(m.ullTotalPhys / 1048576)
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal"):
                    return int(line.split()[1]) // 1024
    except Exception:
        pass
    return 16384

def open_path(path):
    try:
        if IS_WIN:
            os.startfile(path)
        else:
            subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def flat_button(parent, text, cmd, bg, fg, hover, font, pady):
    b = tk.Label(parent, text=text, bg=bg, fg=fg, font=font, cursor="hand2", pady=pady)
    b._bg, b._hover = bg, hover
    b.bind("<Button-1>", lambda e: cmd())
    b.bind("<Enter>", lambda e: b.config(bg=b._hover))
    b.bind("<Leave>", lambda e: b.config(bg=b._bg))
    return b

class Slider(tk.Canvas):
    """Плавный ползунок с шагом step."""
    def __init__(self, master, lo, hi, step, value, command=None, bg=CARD):
        super().__init__(master, height=38, bg=bg, highlightthickness=0, cursor="hand2")
        self.lo, self.hi, self.step, self.command = lo, hi, step, command
        self.value = max(lo, min(hi, int(round(value / step) * step)))
        self.hover = False
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<Button-1>", self.click)
        self.bind("<B1-Motion>", self.click)
        self.bind("<Enter>", lambda e: self.set_hover(True))
        self.bind("<Leave>", lambda e: self.set_hover(False))
        self.bind("<MouseWheel>", lambda e: self.set(self.value + (self.step if e.delta > 0 else -self.step)))

    def set_hover(self, h):
        self.hover = h
        self.draw()

    def set(self, v):
        v = max(self.lo, min(self.hi, int(round(v / self.step) * self.step)))
        if v != self.value:
            self.value = v
            self.draw()
            if self.command:
                self.command(v)

    def click(self, e):
        w, pad = self.winfo_width(), 16
        frac = max(0.0, min(1.0, (e.x - pad) / max(1, w - 2 * pad)))
        self.set(self.lo + frac * (self.hi - self.lo))

    def draw(self):
        self.delete("all")
        w, y, pad = self.winfo_width(), 19, 16
        x = pad + (w - 2 * pad) * (self.value - self.lo) / max(1, self.hi - self.lo)
        self.create_line(pad, y, w - pad, y, width=8, fill=FIELD, capstyle="round")
        self.create_line(pad, y, max(pad, x), y, width=8, fill=ACC, capstyle="round")
        r = 15 if self.hover else 12
        self.create_oval(x - r - 5, y - r - 5, x + r + 5, y + r + 5, fill=mix(CARD, ACC, 0.18), outline="")
        self.create_oval(x - r, y - r, x + r, y + r, fill=ACC, outline="")
        self.create_oval(x - r + 5, y - r + 5, x + r - 5, y + r - 5, fill="#ffffff", outline="")

class App(tk.Tk):
    def __init__(self):
        super().__init__(className="SKLLauncher")
        self.title(APP)
        self.geometry("820x720")
        self.minsize(560, 680)
        self.configure(bg=BG)
        self.q = queue.Queue()
        self.cfg = self.load_cfg()
        lang, ask = initial_lang(self.cfg)
        set_lang(lang)
        self.cfg.setdefault("ram", 2048)
        self.cfg.setdefault("close_on_launch", True)
        self.cfg.setdefault("anim", True)
        self.manifest = []
        self.forge, self.forge_rec = {}, {}
        self.fabric_games, self.fabric_loaders = set(), []
        self.of = {}
        self.known_ids = set()
        self.busy = False
        self._dl_only = False
        self.parts = []
        self.log_visible = False
        self.max_ram = max(2048, min(32768, (total_ram_mb() * 3 // 4) // 128 * 128))
        self.loader = tk.StringVar(value=self.cfg.get("loader", "Vanilla"))
        self.snap = tk.BooleanVar(value=self.cfg.get("snap", False))
        self.nick = tk.StringVar(value=self.cfg.get("nick", "Player"))
        self.build_ui()
        if ask:
            self.after(600, self.ask_language)
        self.after(100, self.poll)
        self.after(33, self.animate)
        self.load_data_async()
        self.after(300000, self.auto_refresh)

    # --- конфиг
    def load_cfg(self):
        try:
            with open(CONFIG, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_cfg(self):
        self.cfg.update(lang=LANG, nick=self.nick.get(), loader=self.loader.get(), snap=self.snap.get(),
                        version=self.ver_box.get())
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump(self.cfg, f, indent=2)

    # --- UI
    def build_ui(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("TCombobox", fieldbackground=FIELD, background=FIELD, foreground=FG,
                     arrowcolor=ACC, bordercolor=FIELD, lightcolor=FIELD, darkcolor=FIELD, padding=6)
        st.map("TCombobox", fieldbackground=[("readonly", FIELD), ("disabled", FIELD)],
               foreground=[("readonly", FG), ("disabled", MUTED)],
               selectbackground=[("readonly", FIELD)], selectforeground=[("readonly", FG)])
        st.configure("Horizontal.TProgressbar", troughcolor=FIELD, background=ACC, bordercolor=CARD,
                     lightcolor=ACC, darkcolor=ACC, thickness=6)
        self.option_add("*TCombobox*Listbox.background", FIELD)
        self.option_add("*TCombobox*Listbox.foreground", FG)
        self.option_add("*TCombobox*Listbox.selectBackground", ACC)
        self.option_add("*TCombobox*Listbox.selectForeground", BG)

        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.logo_icon = tk.PhotoImage(data=LOGO_ICON_B64)
        self.iconphoto(True, self.logo_icon)          # иконка окна вместо пера
        self.logo_head = tk.PhotoImage(data=LOGO_HEAD_B64)
        self.t0 = self.canvas.create_image(0, 0, image=self.logo_head, anchor="w")
        self.f1 = tkfont.Font(family=FONT, size=34, weight="bold")
        self.f2 = tkfont.Font(family=FONT, size=34)
        self.t1 = self.canvas.create_text(0, 0, text="SKL", fill=ACC, font=self.f1, anchor="w")
        self.t2 = self.canvas.create_text(0, 0, text=" LAUNCHER", fill=FG, font=self.f2, anchor="w")

        self.gear = tk.Label(self.canvas, text="⚙", bg=BG, fg=MUTED, font=(FONT_SYM, 20), cursor="hand2")
        self.gear.bind("<Button-1>", lambda e: self.open_settings())
        self.gear.bind("<Enter>", lambda e: self.gear.config(fg=ACC))
        self.gear.bind("<Leave>", lambda e: self.gear.config(fg=MUTED))
        self.gear_win = self.canvas.create_window(0, 0, window=self.gear, anchor="ne")

        card = self.card = tk.Frame(self.canvas, bg=CARD, padx=28, pady=24)
        self.card_win = self.canvas.create_window(0, 0, window=card, anchor="n")

        reg(tk.Label(card, text=tr("nick"), bg=CARD, fg=MUTED, font=(FONT, 8, "bold")), "nick").pack(anchor="w")
        tk.Entry(card, textvariable=self.nick, bg=FIELD, fg=FG, insertbackground=ACC, relief="flat",
                 font=(FONT, 13), highlightthickness=1, highlightbackground=FIELD,
                 highlightcolor=ACC).pack(fill="x", ipady=7, pady=(3, 14))

        seg = tk.Frame(card, bg=CARD)
        seg.pack(fill="x", pady=(0, 14))
        self.seg_btns = {}
        for name in ("Vanilla", "Forge", "Fabric", "OptiFine"):
            b = tk.Label(seg, text=name, bg=FIELD, fg=MUTED, font=(FONT, 10, "bold"), cursor="hand2", pady=8)
            b.pack(side="left", expand=True, fill="x", padx=(0 if name == "Vanilla" else 2, 0))
            b.bind("<Button-1>", lambda ev, n=name: self.set_loader(n))
            self.seg_btns[name] = b

        reg(tk.Label(card, text=tr("mcver"), bg=CARD, fg=MUTED, font=(FONT, 8, "bold")), "mcver").pack(anchor="w")
        self.ver_box = ttk.Combobox(card, state="readonly", font=(FONT, 11))
        self.ver_box.pack(fill="x", pady=(3, 4))
        self.ver_box.bind("<<ComboboxSelected>>", lambda ev: self.update_lvers())
        reg(tk.Checkbutton(card, text=tr("snaps"), variable=self.snap,
                       command=self.refresh_versions, bg=CARD, fg=MUTED, activebackground=CARD,
                       activeforeground=FG, selectcolor=FIELD, font=(FONT, 9), bd=0,
                       highlightthickness=0), "snaps").pack(anchor="w", pady=(0, 10))

        reg(tk.Label(card, text=tr("lver"), bg=CARD, fg=MUTED, font=(FONT, 8, "bold")), "lver").pack(anchor="w")
        self.lver_box = ttk.Combobox(card, state="readonly", font=(FONT, 11))
        self.lver_box.pack(fill="x", pady=(3, 16))
        self.lver_box.bind("<<ComboboxSelected>>", lambda ev: self.update_play())

        self.play = flat_button(card, tr("play"), self.on_play, ACC, "#0b1a10", ACC2, (FONT, 16, "bold"), 12)
        self.play.pack(fill="x")
        self.folder_btn = flat_button(card, FOLDER_ICON + tr("openfolder"), self.open_folder,
                                      FIELD, FG, mix(FIELD, ACC, 0.25), (FONT, 10), 8)
        self.folder_btn.pack(fill="x", pady=(8, 10))

        self.pbar = ttk.Progressbar(card, mode="determinate")
        self.pbar.pack(fill="x")
        self.status = tk.Label(card, text=tr("loading"), bg=CARD, fg=MUTED, font=(FONT, 9))
        self.status.pack(pady=(6, 0))
        self.log_toggle = tk.Label(card, text=tr("showlog"), bg=CARD, fg=MUTED, font=(FONT, 8),
                                   cursor="hand2")
        self.log_toggle.pack(pady=(4, 0))
        self.log_toggle.bind("<Button-1>", lambda e: self.toggle_log())
        self.logbox = tk.Text(card, height=6, bg="#0e0e14", fg=MUTED, relief="flat", font=("Consolas", 8),
                              state="disabled", wrap="none")

        self.canvas.bind("<Configure>", self.relayout)
        self.paint_loader()

    def relayout(self, e=None):
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        if w < 50:
            return
        fs = int(max(22, min(44, w / 20)))
        self.f1.configure(size=fs)
        self.f2.configure(size=fs)
        wa, wb = self.f1.measure("SKL"), self.f2.measure(" LAUNCHER")
        hy = 20 + fs * 1.1
        lw = self.logo_head.width()
        x0 = w / 2 - (lw + 14 + wa + wb) / 2
        self.canvas.coords(self.t0, x0, hy)
        x1 = x0 + lw + 14
        self.canvas.coords(self.t1, x1, hy)
        self.canvas.coords(self.t2, x1 + wa, hy)
        self.canvas.coords(self.gear_win, w - 16, 12)
        hdr = hy + fs * 1.0
        cw = int(max(380, min(580, w - 60)))
        self.canvas.itemconfigure(self.card_win, width=cw)
        self.update_idletasks()
        ch = self.card.winfo_reqheight()
        y = max(hdr, hdr + (h - hdr - ch) / 2 - 10)
        self.canvas.coords(self.card_win, w / 2, y)
        self.hdr_needed = hdr + ch + 20
        if self.parts:
            self.sync_particles()

    def toggle_log(self):
        self.log_visible = not self.log_visible
        if self.log_visible:
            self.logbox.pack(fill="x", pady=(6, 0))
            self.log_toggle.config(text=tr("hidelog"))
        else:
            self.logbox.pack_forget()
            self.log_toggle.config(text=tr("showlog"))
        self.relayout()
        need = int(getattr(self, "hdr_needed", 0))
        if self.winfo_height() < need:
            self.geometry("%dx%d" % (self.winfo_width(), need))

    # --- анимированный фон
    def spawn_particle(self, w, h, anywhere=True):
        d = random.random()
        size = int(6 + d * 28)
        x = random.uniform(0, w)
        y = random.uniform(0, h) if anywhere else h
        col = mix(BG, ACC, 0.04 + 0.15 * d)
        it = self.canvas.create_rectangle(x, y, x + size, y + size, fill=col, outline="", tags="p")
        self.parts.append((it, size, 0.25 + d * 0.9, random.uniform(-0.25, 0.25)))

    def init_particles(self):
        self.canvas.delete("p")
        self.parts = []
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        if w < 100 or h < 100:
            return                      # окно ещё не отрисовано, попробуем на следующем кадре
        self._psize = (w, h)
        self.sync_particles()

    def sync_particles(self):
        """Растягивает фон под текущий размер окна и держит плотность частиц."""
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        if w < 100 or h < 100:
            return
        ow, oh = getattr(self, "_psize", (w, h))
        if (w, h) != (ow, oh):
            sx, sy = w / max(ow, 1), h / max(oh, 1)
            for it, size, sp, dx in self.parts:
                x1, y1, x2, y2 = self.canvas.coords(it)
                self.canvas.coords(it, x1 * sx, y1 * sy, x1 * sx + size, y1 * sy + size)
            self._psize = (w, h)
        target = int(max(20, min(140, 38 * (w * h) / (820 * 720))))
        while len(self.parts) < target:
            self.spawn_particle(w, h)
        while len(self.parts) > target:
            self.canvas.delete(self.parts.pop()[0])
        self.canvas.tag_lower("p")

    def animate(self):
        try:
            if self.cfg.get("anim", True):
                if not self.parts:
                    self.init_particles()
                if self.state() == "normal":
                    w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
                    for it, size, sp, dx in self.parts:
                        self.canvas.move(it, dx, -sp)
                        x1, y1, x2, y2 = self.canvas.coords(it)
                        if y2 < 0 or x2 < -10 or x1 > w + 10:
                            nx = random.uniform(0, w)
                            self.canvas.coords(it, nx, h, nx + size, h + size)
            elif self.parts:
                self.canvas.delete("p")
                self.parts = []
        except Exception:
            pass
        self.after(33, self.animate)

    # --- настройки
    def change_lang(self, code):
        set_lang(code)
        self.cfg["lang"] = LANG
        self.save_cfg()
        self.apply_lang()

    def apply_lang(self):
        for w, key in LANG_WIDGETS:
            try:
                w.config(text=tr(key))
            except Exception:
                pass
        if self.busy:
            self.play.config(text=tr("downloading") if self._dl_only else tr("starting"))
        else:
            self.update_play()
        self.folder_btn.config(text=FOLDER_ICON + tr("openfolder"))
        self.log_toggle.config(text=tr("hidelog") if self.log_visible else tr("showlog"))
        if not self.manifest:
            self.set_status(tr("loading"))

    def ask_language(self):
        d = tk.Toplevel(self)
        d.title("Language / Язык")
        d.configure(bg=CARD)
        d.resizable(False, False)
        d.transient(self)
        d.geometry("340x210+%d+%d" % (self.winfo_x() + 240, self.winfo_y() + 200))
        tk.Label(d, text="Choose your language\nВыберите язык", bg=CARD, fg=FG, font=(FONT, 12, "bold"),
                 justify="center").pack(pady=(24, 14))
        def pick(c):
            self.change_lang(c)
            d.destroy()
        for code, name in (("en", "English"), ("ru", "Русский")):
            flat_button(d, name, lambda c=code: pick(c), ACC, "#0b1a10", ACC2, (FONT, 12, "bold"), 8).pack(fill="x", padx=40, pady=4)
        d.protocol("WM_DELETE_WINDOW", lambda: pick("en"))
        d.grab_set()

    def open_settings(self):
        if getattr(self, "_set", None) is not None and self._set.winfo_exists():
            self._set.lift()
            return
        t = self._set = tk.Toplevel(self)
        t.title(tr("settings"))
        t.configure(bg=CARD)
        t.resizable(False, False)
        t.transient(self)
        t.geometry("440x475+%d+%d" % (self.winfo_x() + 80, self.winfo_y() + 80))
        pad = tk.Frame(t, bg=CARD, padx=28, pady=22)
        pad.pack(fill="both", expand=True)
        tk.Label(pad, text=tr("settings"), bg=CARD, fg=FG, font=(FONT, 16, "bold")).pack(anchor="w", pady=(0, 14))

        row = tk.Frame(pad, bg=CARD)
        row.pack(fill="x")
        tk.Label(row, text=tr("ram"), bg=CARD, fg=MUTED, font=(FONT, 8, "bold")).pack(side="left")
        lbl = tk.Label(row, bg=CARD, fg=ACC, font=(FONT, 10, "bold"))
        lbl.pack(side="right")
        def on_ram(v):
            self.cfg["ram"] = v
            lbl.config(text=tr("ramfmt", v, v / 1024))
            self.save_cfg()
        sl = Slider(pad, 512, self.max_ram, 128, self.cfg["ram"], on_ram)
        sl.pack(fill="x", pady=(4, 0))
        self.cfg["ram"] = sl.value
        lbl.config(text=tr("ramfmt", sl.value, sl.value / 1024))
        tk.Label(pad, text=tr("raminfo", total_ram_mb() / 1024),
                 bg=CARD, fg=MUTED, font=(FONT, 8), wraplength=360, justify="left").pack(anchor="w", pady=(2, 16))

        def check(text, key):
            var = tk.BooleanVar(value=self.cfg.get(key, True))
            def ch():
                self.cfg[key] = var.get()
                self.save_cfg()
            tk.Checkbutton(pad, text=text, variable=var, command=ch, bg=CARD, fg=FG, activebackground=CARD,
                           activeforeground=FG, selectcolor=FIELD, font=(FONT, 10), bd=0,
                           highlightthickness=0).pack(anchor="w", pady=3)
        check(tr("hide"), "close_on_launch")
        check(tr("anim"), "anim")
        check(tr("shared"), "shared_folders")

        lrow = tk.Frame(pad, bg=CARD)
        lrow.pack(fill="x", pady=(14, 0))
        tk.Label(lrow, text=tr("language"), bg=CARD, fg=MUTED, font=(FONT, 8, "bold")).pack(side="left")
        for code, name in (("ru", "Русский"), ("en", "English")):
            cur = LANG == code
            flat_button(lrow, name, lambda c=code: (self.change_lang(c), t.destroy(), self.after(60, self.open_settings)),
                        ACC if cur else FIELD, "#0b1a10" if cur else FG, ACC2 if cur else mix(FIELD, ACC, 0.25),
                        (FONT, 10, "bold"), 6).pack(side="right", padx=(6, 0))
        flat_button(pad, tr("done"), t.destroy, ACC, "#0b1a10", ACC2, (FONT, 11, "bold"), 8).pack(fill="x", pady=(18, 0))

    def paint_loader(self):
        for n, b in self.seg_btns.items():
            sel = n == self.loader.get()
            b.config(bg=ACC if sel else FIELD, fg="#0b1a10" if sel else MUTED)
        self.lver_box.config(state="disabled" if self.loader.get() == "Vanilla" else "readonly")

    def set_loader(self, n):
        if self.busy:
            return
        self.loader.set(n)
        self.paint_loader()
        self.refresh_versions()

    # --- очередь UI из потоков
    def ui(self, fn, *a):
        self.q.put((fn, a))

    def poll(self):
        try:
            while True:
                fn, a = self.q.get_nowait()
                fn(*a)
        except queue.Empty:
            pass
        self.after(100, self.poll)

    def set_status(self, t): self.status.config(text=t)
    def set_progress(self, d, t): self.pbar.config(maximum=max(t, 1), value=d)
    def add_log(self, t):
        self.logbox.config(state="normal")
        self.logbox.insert("end", t + "\n")
        self.logbox.see("end")
        self.logbox.config(state="disabled")

    # --- данные
    def load_data_async(self):
        def task(fn):
            try:
                fn()
            except Exception as e:
                self.ui(self.add_log, tr("data_err", e))
        for fn in (self.fetch_manifest, self.fetch_forge, self.fetch_fabric, self.fetch_optifine):
            threading.Thread(target=task, args=(fn,), daemon=True).start()

    def fetch_manifest(self):
        cache = os.path.join(CACHE, "manifest.json")
        try:
            raw = http_get(MANIFEST_URL)
            with open(cache, "wb") as f:
                f.write(raw)
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            with open(cache, encoding="utf-8") as f:
                data = json.load(f)
        self.ui(self.apply_manifest, data["versions"])

    def apply_manifest(self, versions):
        new = [v["id"] for v in versions if v["id"] not in self.known_ids]
        if self.known_ids and new:
            self.add_log(tr("newver") + ", ".join(new[:5]))
        self.known_ids = {v["id"] for v in versions}
        self.manifest = versions
        self.refresh_versions()
        self.set_status(tr("ready"))

    def fetch_forge(self):
        root = ET.fromstring(http_get(FORGE_META))
        res = {}
        for v in root.findall("./versioning/versions/version"):
            full = v.text.strip()
            mc = full.split("-")[0]
            try:
                if vtuple(mc) < (1, 7, 10):
                    continue
            except Exception:
                continue
            res.setdefault(mc, []).append(full)
        try:
            promos = get_json(FORGE_PROMOS).get("promos", {})
            self.forge_rec = {k[:-12]: v for k, v in promos.items() if k.endswith("-recommended")}
        except Exception:
            self.forge_rec = {}
        self.forge = res
        self.ui(self.refresh_versions)

    def fetch_fabric(self):
        games = get_json(FABRIC_META + "/game")
        loaders = get_json(FABRIC_META + "/loader")
        self.fabric_games = {g["version"] for g in games}
        stable = [l["version"] for l in loaders if l.get("stable")]
        self.fabric_loaders = stable or [l["version"] for l in loaders]
        self.ui(self.refresh_versions)

    def fetch_optifine(self):
        lst = get_json(OPTIFINE_LIST)
        res = {}
        for e in lst:
            mc = e.get("mcversion")
            if mc and e.get("patch") and e.get("type"):
                res.setdefault(mc, []).append({"type": e["type"], "patch": e["patch"]})
        def key(e):
            m = re.match(r"([A-Z])(\d+)(?:_pre(\d+))?", e["patch"])
            if not m:
                return ("", 0, 0, 0)
            return (m.group(1), int(m.group(2)), 0 if m.group(3) else 1, int(m.group(3) or 0))
        for mc in res:
            try:
                res[mc].sort(key=key, reverse=True)
            except Exception:
                pass
        self.of = res
        self.ui(self.refresh_versions)

    def auto_refresh(self):
        def t():
            try:
                self.fetch_manifest()
            except Exception:
                pass
        threading.Thread(target=t, daemon=True).start()
        self.after(300000, self.auto_refresh)

    def refresh_versions(self):
        if not self.manifest:
            return
        loader = self.loader.get()
        vers = [v for v in self.manifest if v["type"] == "release" or self.snap.get()]
        if loader == "Forge":
            vers = [v for v in vers if v["id"] in self.forge]
        elif loader == "Fabric":
            vers = [v for v in vers if v["id"] in self.fabric_games]
        elif loader == "OptiFine":
            vers = [v for v in vers if v["id"] in self.of]
        ids = [v["id"] for v in vers]
        self.ver_box["values"] = ids
        cur = self.ver_box.get() or self.cfg.get("version")
        self.ver_box.set(cur if cur in ids else (ids[0] if ids else ""))
        self.update_lvers()

    def update_lvers(self):
        loader, mc = self.loader.get(), self.ver_box.get()
        vals, star = [], None
        if loader == "Forge":
            vals = [f.split("-", 1)[1] for f in reversed(self.forge.get(mc, []))]
            rec = self.forge_rec.get(mc)
            if rec:
                star = next((v for v in vals if v == rec or v.startswith(rec + "-")), None)
        elif loader == "Fabric":
            vals = list(self.fabric_loaders)
            star = vals[0] if vals else None
        elif loader == "OptiFine":
            vals = ["%s_%s" % (e["type"], e["patch"]) for e in self.of.get(mc, [])]
            star = next((v for v, e in zip(vals, self.of.get(mc, [])) if "pre" not in e["patch"]), None)
        if star:
            vals = [star] + [v for v in vals if v != star]
        self.lver_box["values"] = vals
        self.lver_box.set(vals[0] if vals else "")   # самая стабильная всегда первая и выбрана
        self.paint_loader()
        self.update_play()

    def update_play(self):
        """Кнопка: ИГРАТЬ, если версия уже скачана, иначе СКАЧАТЬ."""
        if self.busy or not hasattr(self, "play"):
            return
        ok = version_installed(self.ver_box.get(), self.loader.get(), self.lver_box.get().strip())
        self.play.config(text=tr("play") if ok else tr("download"))

    # --- запуск
    def instance_name(self):
        mc, loader = self.ver_box.get(), self.loader.get()
        return mc if loader == "Vanilla" else "%s-%s" % (loader, mc)

    def open_folder(self):
        path = ROOT
        if not self.cfg.get("shared_folders", True) and self.ver_box.get():
            path = os.path.join(INSTANCES, self.instance_name())     # у версии свои моды и шейдеры
            for n in SHARED:
                os.makedirs(os.path.join(path, n), exist_ok=True)
        os.makedirs(path, exist_ok=True)
        open_path(path)

    def on_play(self):
        if self.busy:
            return
        nick = self.nick.get().strip()
        if not re.fullmatch(r"[A-Za-z0-9_]{3,16}", nick):
            messagebox.showwarning(APP, tr("nick_err"))
            return
        mc, loader = self.ver_box.get(), self.loader.get()
        lver = self.lver_box.get().strip()
        if not mc:
            messagebox.showwarning(APP, tr("vers_wait"))
            return
        if loader != "Vanilla" and not lver:
            messagebox.showwarning(APP, tr("no_lver"))
            return
        self.save_cfg()
        download_only = not version_installed(mc, loader, lver)
        self._dl_only = download_only
        self.busy = True
        self.play.config(bg="#3a3a4a", fg=MUTED,
                         text=tr("downloading") if download_only else tr("starting"))
        self.play._bg = self.play._hover = "#3a3a4a"
        threading.Thread(target=self.launch, args=(nick, mc, loader, lver, int(self.cfg["ram"]),
                                                   self.instance_name(), self.cfg.get("close_on_launch", True),
                                                   download_only),
                         daemon=True).start()

    def finish(self):
        self.busy = False
        self._dl_only = False
        self.play.config(bg=ACC, fg="#0b1a10")
        self.play._bg, self.play._hover = ACC, ACC2
        self.set_progress(0, 1)
        self.update_play()

    def hide_window(self):
        self.withdraw()

    def show_window(self):
        self.deiconify()
        self.lift()
        self.focus_force()

    def prepare_game(self, nick, mc, loader, lver, ram, inst, rep):
        """Скачивает всё нужное для версии и собирает команду запуска."""
        entry = next(v for v in self.manifest if v["id"] == mc)
        vdata = ensure_vanilla(entry, rep)
        java = ensure_java(vdata.get("javaVersion", {}).get("majorVersion", 8), rep)
        if loader == "Vanilla":
            vid = mc
        elif loader == "Forge":
            fver = "%s-%s" % (mc, lver)
            vid = forge_installed(fver) or install_forge(fver, java, rep)
        elif loader == "Fabric":
            vid = install_fabric(mc, lver, rep)
        else:
            e = next(x for x in self.of[mc] if "%s_%s" % (x["type"], x["patch"]) == lver)
            vid = install_optifine(mc, e, java, rep)
        data = load_version(vid)
        gamedir = os.path.join(INSTANCES, inst)
        os.makedirs(gamedir, exist_ok=True)
        link_shared(gamedir, rep, self.cfg.get("shared_folders", True))
        cp, natives = prepare_libraries(data, rep)
        idx_id, game_assets = prepare_assets(data, gamedir, rep)
        ndir = os.path.join(VERSIONS, data["_root"], "natives")
        extract_natives(natives, ndir)
        cmd = build_command(java, data, vid, nick, ram, cp, ndir, gamedir, idx_id, game_assets)
        return cmd, vid, gamedir

    def launch(self, nick, mc, loader, lver, ram, inst, hide, download_only):
        rep = Reporter(self)
        hidden = False
        try:
            cmd, vid, gamedir = self.prepare_game(nick, mc, loader, lver, ram, inst, rep)
            if download_only:
                rep.status(tr("installed_ok"))
                return
            rep.status(tr("game_start"))
            rep.log(tr("log_launch") + vid)
            p = subprocess.Popen(cmd, cwd=gamedir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 creationflags=NO_WINDOW)
            rep.status(tr("game_run"))
            if hide:
                hidden = True
                self.ui(self.hide_window)
            for line in iter(p.stdout.readline, b""):
                rep.log(line.decode("utf-8", "replace").rstrip())
            code = p.wait()
            rep.status(tr("game_closed") + ("" if code == 0 else tr("closed_code", code)))
        except Exception as e:
            rep.status(tr("err", e))
            rep.log(tr("err_log", e))
        finally:
            if hidden:
                self.ui(self.show_window)
            self.ui(self.finish)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--make-icon":   # создаёт icon.ico из встроенного логотипа
        import io, base64
        from PIL import Image
        im = Image.open(io.BytesIO(base64.b64decode(LOGO_ICON_B64))).convert("RGBA")
        im.save("icon.ico", sizes=[(s, s) for s in (128, 64, 48, 32, 24, 16)])
        print("icon.ico created")
        sys.exit(0)
    if len(sys.argv) > 1 and sys.argv[1] == "--check":      # проверка, что лаунчер запускается
        print("ok")
        sys.exit(0)
    try:
        if IS_WIN:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("SKL.Launcher")
    except Exception:
        pass
    App().mainloop()
